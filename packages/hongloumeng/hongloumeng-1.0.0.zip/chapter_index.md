# Chapter Index

**Chapters**: 6

| # | Title | File |
|---|---|---|
| 1 | 虚实交织的叙事框架与哲学基础 | chapters/01-narrative-framework-philosophy.md |
| 2 | 权力代理机制与危机调解模式 | chapters/02-power-proxy-crisis-management.md |
| 3 | 情感债务模型与三角关系博弈 | chapters/03-emotional-debt-triangle-dynamics.md |
| 4 | 符号系统对抗与虚实辩证 | chapters/04-symbolic-system-conflict.md |
| 5 | 家族衰败的谶语系统与宿命预警 | chapters/05-family-decline-prophecy.md |
| 6 | 结局的宿命闭环与哲学升华 | chapters/06-final-fate-closure.md |