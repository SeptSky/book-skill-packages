# Chapter Index

**Chapters**: 6

| # | Title | File |
|---|---|---|
| 1 | 统治合法性与继承机制 | chapters/01-legitimacy-succession.md |
| 2 | 国家架构与行政管控 | chapters/02-state-structure-admin.md |
| 3 | 军事征服与地缘战略 | chapters/03-military-geo-strategy.md |
| 4 | 人才网络与官僚生态 | chapters/04-talent-bureaucratic-ecology.md |
| 5 | 社会秩序与文化治理 | chapters/05-social-order-cultural-gov.md |
| 6 | 政治风险与危机决策 | chapters/06-political-risk-crisis-decision.md |