# Chapter Index

**Chapters**: 10

| # | Title | File |
|---|---|---|
| 1 | 宇宙生成与地理框架 | chapters/01-cosmogony-and-geography.md |
| 2 | 灵根起源与水帘洞试炼 | chapters/02-stone-monkey-origin.md |
| 3 | 天庭秩序与修行隐喻 | chapters/03-heavenly-rebellion.md |
| 4 | 阴司对案与生死簿篡改 | chapters/04-underworld-intervention.md |
| 5 | 紧箍咒契约与师徒权力重构 | chapters/05-journey-initiation.md |
| 6 | 跨域协作与身份合法性重构 | chapters/06-pig-and-sand-recruitment.md |
| 7 | 妖魔政权与修行考验模式 | chapters/07-temple-and-demon-confrontation.md |
| 8 | 法宝争夺与跨域权威协调 | chapters/08-fire-flame-mountain.md |
| 9 | 身份伪装与权力象征物政治 | chapters/09-false-buddha-crisis.md |
| 10 | 终极考验与因果闭环 | chapters/10-final-battle-arc.md |