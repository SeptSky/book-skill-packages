# Chapter Index

**Chapters**: 8

| # | Title | File |
|---|---|---|
| 1 | 政治秩序与合法性构建 | chapters/01-political-order-and-legitimacy.md |
| 2 | 危机预警与灾异应对 | chapters/02-crisis-warning-and-disaster-response.md |
| 3 | 军事战略与战术博弈 | chapters/03-military-strategy-and-tactical-gaming.md |
| 4 | 指挥体系与将领任用 | chapters/04-command-structure-and-personnel-loyalty.md |
| 5 | 外交博弈与边疆治理 | chapters/05-diplomacy-and-border-governance.md |
| 6 | 民生治理与财政经济 | chapters/06-livelihood-fiscal-and-social-governance.md |
| 7 | 权力交接与宫廷政治 | chapters/07-power-transition-and-court-politics.md |
| 8 | 君主修养与决策心理 | chapters/08-monarch-cultivation-and-decision-psychology.md |